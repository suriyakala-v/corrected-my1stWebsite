<header>
    <div class="topnav">
        <figure>
            <img src="./assets/img/logo.PNG" alt="logo.PNG"  id="logo"/>
        </figure>
        <a href="manageProduct.php">MANAGE PRODUCT</a>
        <a href="manageCategory.php">MANAGE CATEGORY</a>
    </div>
</header>